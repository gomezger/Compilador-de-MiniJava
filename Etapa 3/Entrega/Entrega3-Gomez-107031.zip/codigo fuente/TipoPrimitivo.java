

public abstract class TipoPrimitivo extends Tipo {
	
	public TipoPrimitivo(String nombre){
		super(nombre);
	}
	
}
