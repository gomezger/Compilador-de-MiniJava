

public class TipoArregloChar extends TipoArreglo {
	
	public TipoArregloChar() {
		super("ArregloChar");
	}


	public void imprimir(){
		System.out.print("TipoArregloChar");
	}
}
