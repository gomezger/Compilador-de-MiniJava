

public class TipoArregloInt extends TipoArreglo {
		
	public TipoArregloInt() {
		super("ArregloInt");
	}

	public void imprimir(){
		System.out.print("TipoArregloInt");
	}

}
