

public class TipoChar extends TipoPrimitivo {
	
	public TipoChar() {
		super("char");
	}

	//metodos	
	public void imprimir(){
		System.out.print("TipoChar");
	}	
}
