

public class TipoBoolean extends TipoPrimitivo {
	public TipoBoolean() {
		super("boolean");
	}

	public void imprimir(){
		System.out.print("TipoBoolean");
	}
}
