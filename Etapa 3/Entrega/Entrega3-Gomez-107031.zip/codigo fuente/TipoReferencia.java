

public abstract class TipoReferencia extends Tipo {

	public TipoReferencia(String nombre) {
		super(nombre);
	}
	
	
	
}
