

public class TipoArregloBoolean extends TipoArreglo {
	
	public TipoArregloBoolean() {
		super("ArregloBoolean");
	}

	
	//metodos	
	public void imprimir(){
		System.out.print("TipoArregloBoolean");
	}
	

}
