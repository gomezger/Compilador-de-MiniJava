


public class TipoVoid extends TipoBase {
	
	public TipoVoid() {
		super("void");
	}
	
}
