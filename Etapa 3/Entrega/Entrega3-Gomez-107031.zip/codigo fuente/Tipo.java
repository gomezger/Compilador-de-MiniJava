

public abstract class Tipo extends TipoBase{

	public Tipo(String nombre){
		super(nombre);
	}
	
}
