


public class TipoString extends TipoReferencia {

	
	public TipoString() {
		super("String");
	}


	//metodos
	public void imprimir(){
		System.out.print("TipoString");
	}




}

