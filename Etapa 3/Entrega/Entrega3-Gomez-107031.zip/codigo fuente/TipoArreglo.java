

public abstract class TipoArreglo extends TipoReferencia {
	
	public TipoArreglo(String nombre) {
		super(nombre);
	}

}
