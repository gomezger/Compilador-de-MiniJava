

public class TipoInt extends TipoPrimitivo {
	public TipoInt() {
		super("int");
	}


	//metodos
	public void imprimir(){
		System.out.print("TipoInt");
	}
}
