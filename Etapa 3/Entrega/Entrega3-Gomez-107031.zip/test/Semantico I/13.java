//arroja errores multiples conforme al logro
class Barco1{
	static void main(){}
	
	Barco1(){
		
	}Barco1(int x){
		
	}
}

class Barco2 extends Hola{
	Barco2(Barco1 s){
		
	}
	
	static int main(){}
	
	static int m1(){
		
	}
	
	static int m1(Barco1 x, int x){
		
	}
	private Barco1 x = 5;
	private Barco1 x = 5;
	private Barco1 x;
	static int m1(int a){
		
	}
	
}
class Auto{
	static void main(){}
}

class Barco1{
	private int s;
	
	Barco(){}
	
	static void mian(){}
}

class Auto{
	
}