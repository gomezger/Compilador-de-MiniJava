//error: verificar que while sin condicion

class Transporte{
	public int hola;

	static void transporte(String ho, int hola){

		while(){{
			
		}}
		
	
	}
	
	
	

}