//error: verificar si hay error con archivo vacio

