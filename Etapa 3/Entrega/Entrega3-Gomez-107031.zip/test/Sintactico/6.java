
//sin errores: veririficar If
class Transporte{
	public int hola;

	Transporte(String ho, int hola){
		if(true)
			if(false)
				if(5*7==(this.hola))
					int x = 9;
				else{
					if(hola[5].met(hola)==7){
						int ty = 8;
					}else
						String hola = "hola";
				}
			else{
				return;
			}		
	
	}

}