//error: crear objeto de boolean

class Transporte{
	public int hola;

	static void transporte(String ho, int hola){
		
		return new boolean;
			
	
	}

}