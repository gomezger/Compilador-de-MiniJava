


public class ExceptionAtributoExiste extends ExceptionSemanticoChequeo {

	private static final long serialVersionUID = 1L;

	public ExceptionAtributoExiste(String var,  int fila, int columna){
		super("Ya existe el atributo '"+var+"' en el bloque, m�todo o clase actual. ",fila,columna);
	}
	
	public ExceptionAtributoExiste(String mensaje){
		super(mensaje);
	}
}
