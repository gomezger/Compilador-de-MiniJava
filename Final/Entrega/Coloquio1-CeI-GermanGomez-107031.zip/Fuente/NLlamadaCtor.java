

public abstract class NLlamadaCtor extends NPrimario {
	
	
	//constrcutor
	protected NLlamadaCtor(Token token, NEncadenado enc){
		super(token,enc);
	}
	
}
