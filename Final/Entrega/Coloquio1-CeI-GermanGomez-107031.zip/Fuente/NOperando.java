

public abstract class NOperando extends NExpresion {
	//constrcutor
	protected NOperando(Token token){
		super(token);
	}
	
}
