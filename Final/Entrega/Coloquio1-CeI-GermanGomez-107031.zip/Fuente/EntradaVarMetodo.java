

public abstract class EntradaVarMetodo extends EntradaVariable {

	protected EntradaVarMetodo(Token token, Tipo tipo) {
		super(token, tipo);
	}

}
