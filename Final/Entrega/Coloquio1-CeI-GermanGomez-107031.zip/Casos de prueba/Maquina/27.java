class A{
	static void main(){
	}
}