//probar si funcionan los while

class A{
	public int a;
	public int b;
	
	static void main(){
		
		while(false){
			(System.printIln(4));			
		}
			
		
	}
	
	dynamic int m1(){
		
	
		
		
	}
	dynamic int m2(){}
}


class B extends A{
	public int c;
	public int d;
	
	dynamic int m3(int a, int b){}
	dynamic int m4(){}
}

class C extends B{
	public int e;
	public int f;
	
	dynamic int m3(int a){}
	dynamic int m5(){}
}

class D extends C{
	dynamic int m1(int b){}
	dynamic int m1(){}
}

