class A {
	static void main(){
		(System.printI(40));
		(System.printIln(40));
		(System.printC('c'));
		(System.printCln('c'));
		(System.printB(true));
		(System.printBln(false));
		(System.println());
		(System.printIln(System.read()));
		(System.printS("Hola Gotti"));
		(System.printSln(", como andas?"));



	}
}