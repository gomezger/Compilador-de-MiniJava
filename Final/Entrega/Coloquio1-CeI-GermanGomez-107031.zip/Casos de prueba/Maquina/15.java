class A {

	static void main(){
		if (1 == 1) {
			(System.printSln("Entre al then 1"));
		}else{
			(System.printSln("Entre al else 1"));
		}

		if (1 != 1) {
			(System.printSln("Entre al then 2"));
		}else{
			(System.printSln("Entre al else 2"));
		}

		if (1 == 1) {
			if (1 == 1) {
				(System.printSln("Entre al then del then "));
			}else{
				(System.printSln("Entre al else del then"));
			}

		}else{
			
		}

		if (new A() == null) {
			(System.printSln("Entre al then 3"));
		}

		if (1 != 1) {
			(System.printSln("Entre al then 4"));
		}




		}











	}

