class Principal {
	static void main(){
		;
		if (true)
			;
	


	}
}