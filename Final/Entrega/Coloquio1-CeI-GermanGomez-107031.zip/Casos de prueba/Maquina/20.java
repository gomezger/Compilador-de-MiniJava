class A {

	static void main(){
		(System.printIln(1+5));
		(System.printIln(1-5));
		(System.printIln(1*5));
		(System.printIln(1/5));

		(System.printBln(1 < 5));
		(System.printBln(1 > 5));
		(System.printBln(1 <= 5));
		(System.printBln(1 >= 5));
		(System.printBln(1 == 5));
		(System.printBln(1 != 5));
		(System.printBln(1 < 5  || 5 < 1));
		(System.printBln(1 < 5 && 5 < 1));









	}

}