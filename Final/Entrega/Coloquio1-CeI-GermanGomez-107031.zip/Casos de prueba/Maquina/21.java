class A{
	static void main(){
		int a;
		a = 50;

		(System.printIln(+a));
		(System.printIln(-a));
		(System.printBln(!true));
		(System.printBln(!false));
	}
}