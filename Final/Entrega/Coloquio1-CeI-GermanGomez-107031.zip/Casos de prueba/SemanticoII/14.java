//error: se quiere asignar un boolean a un entero

class Barco extends Transporte{
	private int x;
	
	
	Barco (int a, boolean esta){
		x = true;
	}

	
}


class Transporte{
	public int[] arreglo;
	public int r;
	public Barco b;
	
	
}


class Main{
	
	static void main(){}
	
}