//error: return en constrcutor

class Barco extends Transporte{
	
	
}


class Transporte{
	public int[] arreglo;

	Transporte(){
		return 5;
	}
	
}


class Main{
	
	static void main(){}
	
}