//error: se quiere asignar una clase a un char

class Barco extends Transporte{
	private char x;
	
	
	Barco (int a, boolean esta){
		x = true;
	}

	
}


class Transporte{
	public int[] arreglo;
	public int r;
	public Barco b;
	
	
}


class Main{
	
	static void main(){}
	
}