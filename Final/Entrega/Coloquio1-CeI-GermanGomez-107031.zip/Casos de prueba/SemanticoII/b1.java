//existe la variable en el metodo como local

class Barco extends Transporte{
	
	
}


class Transporte{
	public int[] arreglo;
	public int x;

	static void m1(){
		int a;
		a = 6;
	}
	
	static int m2(){
		return 5;
	}
	
	
}


class Main{
	
	static void main(){}
	
}