//error: return en constrcutor

class Barco extends Transporte{
	
	static int m1(){
		
		int a = 7;
		
		if(true);
		
	}
}


class Transporte{
	public int[] arreglo;

	Transporte(int p){
		
		
		
	}
	
}


class Main{
	
	static void main(){}
	
}