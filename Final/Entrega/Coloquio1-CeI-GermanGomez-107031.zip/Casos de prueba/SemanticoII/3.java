//error: verifico que exp sea de tipo int

class Barco extends Transporte{
	
	
}


class Transporte{
	public int[] arreglo;


	dynamic void m1(){
		boolean[] arreglo = new boolean[5];
		arreglo[2] = true;
		int a = arreglo[true];
	}
	
	
}


class Main{
	
	static void main(){}
	
}