//error: se quiere asignar un char a un tipo clase

class Barco extends Transporte{
	private Transporte x;
	
	
	Barco (int a, boolean esta){
		x = 'a';
	}

	
}


class Transporte{
	public int[] arreglo;
	public int r;
	public Barco b;
	
	
}


class Main{
	
	static void main(){}
	
}