//error: es un encadenado vacio y esta  this solo del lado izquierdo

class Barco extends Transporte{
	
	
}


class Transporte{
	public int[] arreglo;


	dynamic void m1(){
		this = 5+8+7;
	}
	
	
}


class Main{
	
	static void main(){}
	
}