class Miclase{
	dynamic void m1(){
		int a;
		{
			boolean b;
			a=5;
		}
		a = 3;
	}
}

class Main{
static void main(){}
}