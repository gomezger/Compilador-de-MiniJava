//error: verifico que exp sea de tipo int

class Barco extends Transporte{
	
	
}


class Transporte{
	public int[] arreglo;


	dynamic void m1(){
		boolean[] arreglo = new boolean[5];
		arreglo[true] = true;
		int a = arreglo[5];
	}
	
	
}


class Main{
	
	static void main(){}
	
}