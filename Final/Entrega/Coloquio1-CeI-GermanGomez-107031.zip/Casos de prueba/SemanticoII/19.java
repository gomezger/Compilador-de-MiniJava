//error: quiero crear una variable pero ya esta definida en el param

class Barco extends Transporte{
	private Barco x;
	
	
	Barco (int a, boolean esta){
		boolean esta;
	}

	
}


class Transporte{
	public int[] arreglo;
	public int r;
	public Barco b;
	
	
}


class Main{
	
	static void main(){}
	
}