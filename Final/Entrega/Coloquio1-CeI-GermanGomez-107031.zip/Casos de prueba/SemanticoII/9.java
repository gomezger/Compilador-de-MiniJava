//error: no existe la variable en el metodo

class Barco extends Transporte{
	
	
}


class Transporte{
	public int[] arreglo;
	public int x;

	static void m1(){
		a = 6;
	}
	
	static int m2(){
		return 5;
	}
	
	
}


class Main{
	
	static void main(){}
	
}