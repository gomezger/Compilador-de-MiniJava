//error: se quiere asignar un tipo clase a un tipo clase y no son comaptibles

class Barco extends Transporte{
	private Transporte x;
	
	
	Barco (int a, boolean esta){
		x = new Main();;
	}

	
}


class Transporte{
	public int[] arreglo;
	public int r;
	public Barco b;
	
	
}


class Main{
	
	static void main(){}
	
}