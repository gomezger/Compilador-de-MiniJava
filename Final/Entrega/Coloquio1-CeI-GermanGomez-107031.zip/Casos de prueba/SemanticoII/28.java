//error: encadenado en un arreglo

class Barco extends Transporte{
	private Barco x;
	
	
	Barco (int a, boolean esta){
		boolean er;
	}
	
}


class Transporte{
	public int[] arreglo;
	public int r;
	public Barco b;
	private Main m;
	
	
	dynamic void m1(){
		boolean a = true;
		
		if(true){
			arreglo = new int[6+5];
			int h = arreglo[5][5];
		}
		
	}
	
}


class Main{
	
	static void main(){}
	
}