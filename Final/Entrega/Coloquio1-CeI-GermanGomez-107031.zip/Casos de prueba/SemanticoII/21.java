//error: se esperaba una suma de enteros y se encontro suma de int con boolean en expresion de arreglo

class Barco extends Transporte{
	private Barco x;
	
	
	Barco (int a, boolean esta){
		boolean er;
	}
	
}


class Transporte{
	public int[] arreglo;
	public int r;
	public Barco b;
	
	
	dynamic void m1(){
		
		if(true){
			arreglo = new int[true+5];
		}
		
	}
	
}


class Main{
	
	static void main(){}
	
}