//error: existe la variable en el metodo como var de instancia

class Barco extends Transporte{
	
	
}


class Transporte{
	public int[] arreglo;
	public int a;

	static void m1(){
		a = 6;
	}
	
	static int m2(){
		return 5;
	}
	
	
}


class Main{
	
	static void main(){}
	
}