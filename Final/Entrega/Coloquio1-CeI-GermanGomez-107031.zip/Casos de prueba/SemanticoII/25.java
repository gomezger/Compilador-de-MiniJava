//error: se esperaba una suma de enteros y se encontro una comparacion con dos tipos clase no compatibles

class Barco extends Transporte{
	private Barco x;
	
	
	Barco (int a, boolean esta){
		boolean er;
	}
	
}


class Transporte{
	public int[] arreglo;
	public int r;
	public Barco b;
	private Main m;
	
	
	dynamic void m1(){
		boolean a = true;
		
		if(m==b){
			arreglo = new int[6+5];
		}
		
	}
	
}


class Main{
	
	static void main(){}
	
}