
//error=: veririficar parametros incorrecto
class Transporte{

	Transporte(new Transporte(), int hola){
	
	
	}

}