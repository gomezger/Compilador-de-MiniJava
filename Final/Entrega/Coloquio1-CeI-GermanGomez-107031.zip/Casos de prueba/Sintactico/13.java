//verificar si anda mal la creaciond e metodo

class Transporte{
	public int hola;

	public int transporte(String ho, int hola){

		while(true){
			{{
			
			}}
			int x, b, a, r , kk =5;
		}
		

	}
	
	
	

}