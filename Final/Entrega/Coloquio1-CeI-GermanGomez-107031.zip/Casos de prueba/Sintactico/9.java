//error: crear variable que no es atributo en otro lado

class Transporte{
	public int hola;

	static void transporte(String ho, int hola){

			
	
	}
	
	
	int x = 6;

}