//recibir un caracter inesperado dentro de la construccion de un id

public static void main(String[] args) {
        int mÂx;
}