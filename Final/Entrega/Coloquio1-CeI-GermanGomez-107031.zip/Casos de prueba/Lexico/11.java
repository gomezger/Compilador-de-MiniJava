//error al recibir un char vacio

String a = "esto es un string" ;

char a = '';