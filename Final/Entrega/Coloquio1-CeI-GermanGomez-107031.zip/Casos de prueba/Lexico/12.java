//recibir un caracter inesperado como el tilde invertido

public static void main(String[] args) {
        int `name;
}