//error al no tener comilla de cierre en string

String a = "esto es un string;


String hola = "";