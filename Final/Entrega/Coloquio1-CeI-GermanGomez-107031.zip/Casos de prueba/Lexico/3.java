//probar si tira error cuando hay un numero seguido de una variable

int n = 1245a;