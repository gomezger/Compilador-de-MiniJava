//Probar si arroja error por poner un salto de linea literal y no un \n

"Hola que tal
todo bien?"