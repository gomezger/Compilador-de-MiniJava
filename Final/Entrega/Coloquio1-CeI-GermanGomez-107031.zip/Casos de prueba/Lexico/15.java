//Probar si arroja error por no cerrar el string sobre fin de archivo

"Hola que tal