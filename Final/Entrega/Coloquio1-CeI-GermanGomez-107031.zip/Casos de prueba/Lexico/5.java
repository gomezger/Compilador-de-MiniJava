//probar si arroja error al poner & y no &&


if(5<10 & 10==52){
	String hola;
}