//probar si lee correctamente el string vacio

String hola = "";