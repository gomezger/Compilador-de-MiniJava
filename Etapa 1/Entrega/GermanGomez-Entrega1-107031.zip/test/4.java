//probar si detecta el error de fin de linea en un comentario multilinea no cerrado

String hola = "como va?"

/*

hola que tal
aca lleno lugar
chau
no lo cierro