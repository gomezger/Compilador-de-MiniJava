//verificar si '\' arroja error



char a = '\';