//probar si === nos da == y =


if(a===b){
	int n;
}