//error al no tener comilla de cierre en char

char a = 'a;