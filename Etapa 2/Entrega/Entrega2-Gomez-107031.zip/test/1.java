//sin errores

class Barco extends Transporte{
	public boolean [] esta, permitido;
	public boolean pertenece;
	public String cadena;
	public Transporte x;
	
	Barco(boolean [] esta, String cadena, Trasporte x){
		int x;
		if(true && (this.getLancha().setGato())){

			boolean[] casa;
			casa = new boolean[+5];
		}
		
		char c = '\'';
		
		int x = 5;
		a = new int[20*a.met()].met();
		
		
		(met());
		
	}
	
	static String getCadena(){
		cadena = "hola a todos";
	
		hola = new boolean[this.metodo()];
	}
	
	
	dynamic void setPertenece(boolean pertenece){
		if(casa[variable.metodo()]*8+5/(457)){
			
		}else{
			 return;
		}
		
		if(true);
	}
	
	dynamic Transporte getTransporte(){
		
		
		return new Trasponerte(cadena, variable, new char[4*987-878]);
	}
	
}

class Transporte{
	public boolean [] esta, permitido;
	public boolean pertenece;
	public String cadena;
	public Transporte x;
}

