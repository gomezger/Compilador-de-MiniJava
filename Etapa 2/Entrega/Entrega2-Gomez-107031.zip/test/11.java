////sin errores: verificar si te deja poner multiples bloques en un while

class Transporte{
	public int hola;

	static void transporte(String ho, int hola){

		while(true){
			{{
			
			}}
			int x=5;
		}
		

	}
	
	
	

}