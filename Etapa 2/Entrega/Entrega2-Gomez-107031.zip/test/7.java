//error: crear arreglo de cualquier cosa

class Transporte{
	public int hola;

	Transporte(String ho, int hola){
		
		int[] hola;
		hola = new int[+8-7-7-7-7-(hola())];
		
		Barco[] hola;
		hola = new Bardo[5];
			
	
	}

}