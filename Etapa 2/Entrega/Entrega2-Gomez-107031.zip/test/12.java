////sin errores: verificar si te deja crear varaibles con asignacion inline

class Transporte{
	public int hola;

	static void transporte(String ho, int hola){

		while(true){
			{{
			
			}}
			int x, b, a, r , kk =5;
		}
		

	}
	
	
	

}